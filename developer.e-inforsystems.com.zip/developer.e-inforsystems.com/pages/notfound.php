<?php
/**
 * Created by PhpStorm
 * Designed by e-nforsystems Tech
 * <ronoh@e-inforsyste>
 * Copyright ©2015
 * All Rights Reserved
 * Date: 6/20/2015
 * Time: 7:16 AM
 *
 * Package Name: Simple SME Payroll (Kenya)

 * File Name: notfound.php
 *
 */

?>

<div class="col-lg-8 col-lg-offset-2 text-center">
    <div class="logo">
        <h1>Error 404 !</h1>          </div>
    <p class="lead text-muted">Nope, What You Looking is Not here.</p>
</div>