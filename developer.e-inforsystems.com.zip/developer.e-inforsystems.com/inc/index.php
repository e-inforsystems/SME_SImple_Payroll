<?php
/**
 * Created by PhpStorm
 * Designed by Makmesh iKiev
 * <makmesh.x@gmail.com>
 * Copyright ©2015
 * All Rights Reserved
 * Date: 6/20/2015
 * Time: 7:22 AM
 *
 * Package Name: skeleton
 * File Name: index.php
 *
 */

header("Location: ../");
exit;