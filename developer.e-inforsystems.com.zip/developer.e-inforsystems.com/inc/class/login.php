<?php

/**
 * Created by PhpStorm
 * Designed by e-nforsystems Tech
 * <ronoh@e-inforsystems.com>
 * Copyright ©2015
 * All Rights Reserved
 * Date: 6/20/2015
 * Time: 7:16 AM
 *
 * Package Name: Simple SME Payroll (Kenya)
 * File Name: Login.php
 *
 */
class Login extends OurDB
{

    protected $username,
        $password;

    public function __construct($username = '', $passowrd = '')
    {
        if (trim($username) and trim($passowrd)) {
            $this->username = $username;
            $this->password = $passowrd;
        }
    }

    public function user_login()
    {
        $user = self::get_rows("SELECT id, password FROM admin WHERE username = '$this->username' OR
                                  email = '$this->username'");
        $_SESSION['title'] = "Login Notification";
        $_SESSION['message'] = "Wrong username/password combination.";
        if (!$user) {
            header("Location: login.php");
            exit;
        }
        $user = array_shift($user);
        $hashed = self::hash_password();
        if ($user->password != $hashed) {
            header("Location: login.php");
            exit;
        }

        $_SESSION['message'] = "Welcome, $this->username";

        $_SESSION['login'] = array(
            'id' => $user->id, 'username' => $this->username
        );
        header("Location: ./?page=payroll");
        exit;
    }

    protected function hash_password($password = '')
    {
        $pswd = $this->password;
        if (trim($password)) $pswd = $password;
        return hash_hmac('whirlpool', $pswd, '?A?3!?H9??]W:?');
    }

    public function recover_email($email)
    {
        $check = self::get_val("SELECT id FROM admin WHERE email = '$email'");
        $_SESSION['title'] = "Password Recovery!";
        if (!$check) {
            $_SESSION['message'] = 'The email was not found in the system.';
            header("Location: login.php");
            exit;
        }
        $chr = 1234567890;
        $chr = str_shuffle($chr);
        $pswrd = substr($chr, 0, 6);
        $hash = $this->hash_password($pswrd);

        require_once 'PHPMailerAutoload.php';
        $mail = new PHPMailer;

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'your_username@gmail.com';
        $mail->Password = 'your_password';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('your_username@gmail.com', 'Your Name');
        $mail->Subject = 'Password Recovery';
        $mail->Body = 'Your new password is : ' . $pswrd;

        $mail->addAddress($email);

        if (!$mail->send()) {
            $_SESSION['message'] = "Cannot recover password. Please check your internet connection";
        } else {
            self::execute_query("UPDATE admin SET password = '$hash' WHERE email = '$email'");
            $_SESSION['message'] = "A new Password was sent to your email.";
        }

        header("Location: login.php");
        exit;
    }

    public function add_new($item)
    {
        $email = $item['email'];
        $username = $item['username'];
        if (isset($item['id'])) {
            $id = (int)$item['id'];
            $input = array('email' => $email, 'username' => $username);
            if (self::edit('admin', $input, $id))
                return array('user', 'User Notification', 'The changes were saved.');
            return array('user', 'User Notification', 'An internal error occurred. Please try again later.');
        }

        $password = $this->hash_password($_POST['password']);

        $input = array('email' => $email, 'username' => $username, 'password' => $password);

        if (self::insert($input, 'admin'))
            return array('user', 'User Notification', 'The changes were saved.');
        return array('user', 'User Notification', 'An internal error occurred. Please try again later.');
    }

    public function get_users($id = '')
    {
        $sql = 'SELECT id, email, username, password FROM admin';
        if ($id !== '')
            $sql .= ' WHERE id = ' . $id;
        return self::get_rows($sql);
    }

    public function del_user($id)
    {
        $count = self::get_val('SELECT COUNT(id) FROM admin');
        if ($count == 1)
            return 'Sorry, you cannot delete this account. There must be at least one user account.';

        if (self::execute_query("DELETE FROM admin WHERE  id = $id"))
            return 'The account has been removed.';

        return 'An internal error occurred. If you are the developer, check the log files.';
    }

    public function change_password()
    {
        $id = (int)$_POST['id'];
        $old = $this->hash_password($_POST['old']);
        $odl = self::get_val("SELECT password FROM admin WHERE id = $id");

        if ($odl !== $old)
            return array('user', 'User Notification', 'Please enter a valid password for the selected user to continue.');

        $password = $this->hash_password($_POST['password']);

        $input = array('password' => $password);

        if (self::edit('admin', $input, $id))
            return array('user', 'User Notification', 'The changes were saved.');
        return array('user', 'User Notification', 'An internal error occurred. Please try again later.');
    }
}