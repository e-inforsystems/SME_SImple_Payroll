<?php

/**
 * Created by PhpStorm
 * Designed by Makmesh iKiev
 * <wainaina.kelvin@gmail.com>
 * Copyright ©2016
 * All Rights Reserved
 * Date: 10/08/2016
 * Time: 2:11 PM
 *
 * Package Name: payroll
 * File Name: user.php
 *
 */

if (!isset($_SESSION['login']))
    echo <<<MENDE

<script>
    self.location = 'login.php';
</script>

MENDE;

$obj = new Login();
$members = $obj->get_users();

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $meso = $obj->del_user($id);

    $_SESSION['title'] = 'Employee Leave.';

    $_SESSION['message'] = $meso;

    echo <<<MENDE

<script>
    $(function () {
        self.location = '?page=user';
    });
</script>

MENDE;
}
?>

<div class="row">
    <div class="col-lg-12">
        <h1>Users</h1>
    </div>
</div>
<hr/>

<div class="row" style="text-align: right">
    <div class="col-lg-12" style="padding-right: 40px;">
        <a href="#" class="btn btn-success btn-lg btn-round btn-grad" data-toggle="modal"
           data-target="#formModal">Add</a>
    </div>
</div>

<link href="assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet"/>
<div style="height: 30px;"></div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Logins
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Username</th>
                            <th>Email</th>
                            <td></td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $i = 0;
                        $class = array('odd', 'even');
                        if ($members)
                            foreach ($members as $row) {
                                ++$i;
                                echo "<tr><td>$i</td>
                                       <td>$row->username</td><td>$row->email</td>
                                       <td style='text-align: center'><a href='#' about='$row->id' class='del btn btn-danger'>Delete</a> 
                                       <a href='#' class='edit btn btn-warning' data-toggle=\"modal\"
                                            data-target=\"#formEdit\" about='$row->id'>Edit</a>
                                       <a href='#' class='change btn btn-success' data-toggle=\"modal\"
                                            data-target=\"#formChange\" lang='$row->username' about='$row->id'>Change Password</a> </td></tr>";
                            }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="modal fade" id="formModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Add User</h4>
                </div>
                <div class="modal-body">
                    <form role="form" method="post">
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" required class="form-control" name="username"/>
                        </div>

                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" required class="form-control" name="email"/>
                        </div>

                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" required class="form-control" name="password"/>
                        </div>

                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" required class="form-control" name="confirm"/>
                        </div>

                        <div class="modal-footer">
                            <input type="hidden" name="action" value="add_user">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="modal fade" id="formChange" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Change Password for <span class="name"></span></h4>
                </div>
                <div class="modal-body">
                    <form role="form" method="post">
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" required class="form-control" name="old"/>
                        </div>

                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" required class="form-control" name="password"/>
                        </div>

                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" required class="form-control" name="confirm"/>
                        </div>

                        <div class="modal-footer">
                            <input type="hidden" name="action" value="change_password">
                            <input type="hidden" name="id" value="0" id="user_id">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Change Password</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-lg-12">
    <div class="modal fade" id="formEdit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Edit User</h4>
                </div>
                <div class="modal-body">
                    <form role="form" method="post">
                        <div class="rp">

                        </div>
                        <div class="modal-footer">
                            <input type="hidden" name="action" value="add_user">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(function () {
        /*$('.del').on('click', function () {
            var id = $(this).attr('about');
            if (confirm('Do you want to delete the user?'))
                self.location = '?page=user&id=' + id;
        });*/
    });

    /*$('.edit').on('click', function () {
        var id = $(this).attr('about');
        $.post('pages/ajax.php', {edit_user: id}, function (data) {
            $('.rp').html(data);
        });
    });*/

    $('.change').on('click', function () {
        var id = $(this).attr('about');
        var name = $(this).attr('lang');

        $("#user_id").val(id);
        $('.name').text(name);

    });
</script>