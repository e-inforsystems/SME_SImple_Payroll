<?php
/**
  * Created by PhpStorm
 * Designed by meshronoh
 * <meshronoh@gmail.com>
 * Copyright ©2016
 * All Rights Reserved
 * Date: 20/06/2016
 * Time: 10:31 AM
 *
 * Package Name: PayrollPro
 * File Name: notfound.php
 *
 */

?>

<div class="col-lg-8 col-lg-offset-2 text-center">
    <div class="logo">
        <h1>NOTE: ON THIS DEMO, COMPANY PROFILE AND USERS ARE DISABLED !</h1>          </div>
    <p class="lead text-muted">Under Employee Menu</p>
	<p class="lead text-muted">1.Create Employee.... NB/ email address MUST be working</p>
	<p class="lead text-muted">Under Payroll</p>
	<p class="lead text-muted">Check Year And Month of the payroll</p>
	<p class="lead text-muted">2.add allowance,add overtime(if any), minus deductions(if Any)</p>
	<p class="lead text-muted">3. generate payroll</p>
	<p class="lead text-muted">4.generate bank statement</p>
	<p class="lead text-muted">5. print payslip (if Hard Copy Is Required)</p>
	<p class="lead text-muted"> email payslip..(if No hard Copy is required)</p>
	<p class="lead text-muted">Under Respective Menu</p>
	<p class="lead text-muted">check your  P10, P10A, P9A forms For KRA</p>
	<p class="lead text-muted">On Any Issue that is not clear, Feel Free to Call  ..0725965041</p>
	
</div>