<?php
/**
 * Created by PhpStorm
 * Designed by Makmesh iKiev
 * <makmesh.x@gmail.com>
 * Copyright �2015
 * All Rights Reserved
 * Date: 7/13/2015
 * Time: 10:00 AM
 *
 * Package Name: skeleton
 * File Name: notfound.php
 *
 */

?>

<div class="col-lg-8 col-lg-offset-2 text-center">
    <div class="logo">
        <h1>Error 404 !</h1>          </div>
    <p class="lead text-muted">Nope, What You Looking is Not here.</p>
</div>