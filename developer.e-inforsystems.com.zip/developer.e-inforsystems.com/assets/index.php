<?php
/**
 * Created by PhpStorm
 * Designed by Makmesh iKiev
 * <makmesh.x@gmail.com>
 * Copyright ©2016
 * All Rights Reserved
 * Date: 28/01/2016
 * Time: 10:31 AM
 *
 * Package Name: Makmesh Payroll (Kenya)
 * File Name: index.php
 *
 */

