<?php
/**
 * Created by PhpStorm
 * Designed by e-nforsystems Tech
 * <ronoh@e-inforsystems.com>
 * Copyright ©2015
 * All Rights Reserved
 * Date: 6/20/2015
 * Time: 7:16 AM
 *
 * Package Name: Simple SME Payroll (Kenya)