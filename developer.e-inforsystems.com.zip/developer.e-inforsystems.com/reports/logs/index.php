<?php
/**
 * Created by PhpStorm
 * Designed by Makmesh iKiev
 * <makmesh.x@gmail.com>
 * Copyright �2015
 * All Rights Reserved
 * Date: 23/12/2015
 * Time: 1:10 PM
 *
 * Package Name: Makmesh Payroll (Kenya)
 * File Name: index.php
 *
 */

